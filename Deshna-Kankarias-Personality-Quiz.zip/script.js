/*Add your JavaScript here*/

var fantasyScore = 0;
var romanceScore = 0;
var realisticScore = 0;
var historicalScore=0;

var questionsAnswered = 0;

let popup = document.querySelector(".popup");
let confett = document.querySelector("#con");

var result = document.getElementById("result");

var q1a1 = document.getElementById("q1a1");
var q1a2 = document.getElementById("q1a2");
var q1a3 = document.getElementById("q1a3");
var q1a4 = document.getElementById("q1a4");

var q2a1 = document.getElementById("q2a1");
var q2a2 = document.getElementById("q2a2");
var q2a3 = document.getElementById("q2a3");
var q2a4 = document.getElementById("q2a4");

var q3a1 = document.getElementById("q3a1");
var q3a2 = document.getElementById("q3a2");
var q3a3 = document.getElementById("q3a3");
var q3a4 = document.getElementById("q3a4");

var q4a1 = document.getElementById("q4a1");
var q4a2 = document.getElementById("q4a2");
var q4a3 = document.getElementById("q4a3");
var q4a4 = document.getElementById("q4a4");

var q5a1 = document.getElementById("q5a1");
var q5a2 = document.getElementById("q5a2");
var q5a3 = document.getElementById("q5a3");
var q5a4 = document.getElementById("q5a4");


q1a1.addEventListener("click", fantasy);
q1a2.addEventListener("click", romance);
q1a3.addEventListener("click", historical);
q1a4.addEventListener("click", realistic);

q2a1.addEventListener("click", historical);
q2a2.addEventListener("click", romance);
q2a3.addEventListener("click", fantasy);
q2a4.addEventListener("click", realistic);

q3a1.addEventListener("click", realistic);
q3a2.addEventListener("click", romance);
q3a3.addEventListener("click", historical);
q3a4.addEventListener("click", fantasy);

q4a1.addEventListener("click", historical);
q4a2.addEventListener("click", realistic);
q4a3.addEventListener("click", romance);
q4a4.addEventListener("click", fantasy);

q5a1.addEventListener("click", realistic);
q5a2.addEventListener("click", historical);
q5a3.addEventListener("click", fantasy);
q5a4.addEventListener("click", romance);



q1a1.addEventListener('click', function onClick() {
  q1a1.style.backgroundColor = '#ab6878';
  q1a1.style.color = 'white';
});
q1a2.addEventListener('click', function onClick() {
  q1a2.style.backgroundColor = '#ab6878';
  q1a2.style.color = 'white';
});
q1a3.addEventListener('click', function onClick() {
  q1a3.style.backgroundColor = '#ab6878';
  q1a3.style.color = 'white';
});
q1a4.addEventListener('click', function onClick() {
  q1a4.style.backgroundColor = '#ab6878';
  q1a4.style.color = 'white';
});

q2a1.addEventListener('click', function onClick() {
  q2a1.style.backgroundColor = '#ab6878';
  q2a1.style.color = 'white';
});
q2a2.addEventListener('click', function onClick() {
  q2a2.style.backgroundColor = '#ab6878';
  q2a2.style.color = 'white';
});
q2a3.addEventListener('click', function onClick() {
  q2a3.style.backgroundColor = '#ab6878';
  q2a3.style.color = 'white';
});
q2a4.addEventListener('click', function onClick() {
  q2a4.style.backgroundColor = '#ab6878';
  q2a4.style.color = 'white';
});

q3a1.addEventListener('click', function onClick() {
  q3a1.style.backgroundColor = '#ab6878';
  q3a1.style.color = 'white';
});
q3a2.addEventListener('click', function onClick() {
  q3a2.style.backgroundColor = '#ab6878';
  q3a2.style.color = 'white';
});
q3a3.addEventListener('click', function onClick() {
  q3a3.style.backgroundColor = '#ab6878';
  q3a3.style.color = 'white';
});
q3a4.addEventListener('click', function onClick() {
  q3a4.style.backgroundColor = '#ab6878';
  q3a4.style.color = 'white';
});

q4a1.addEventListener('click', function onClick() {
  q4a1.style.backgroundColor = '#ab6878';
  q4a1.style.color = 'white';
});
q4a2.addEventListener('click', function onClick() {
  q4a2.style.backgroundColor = '#ab6878';
  q4a2.style.color = 'white';
});
q4a3.addEventListener('click', function onClick() {
  q4a3.style.backgroundColor = '#ab6878';
  q4a3.style.color = 'white';
});
q4a4.addEventListener('click', function onClick() {
  q4a4.style.backgroundColor = '#ab6878';
  q4a4.style.color = 'white';
});

q5a1.addEventListener('click', function onClick() {
  q5a1.style.backgroundColor = '#ab6878';
  q5a1.style.color = 'white';
});
q5a2.addEventListener('click', function onClick() {
  q5a2.style.backgroundColor = '#ab6878';
  q5a2.style.color = 'white';
});
q5a3.addEventListener('click', function onClick() {
  q5a3.style.backgroundColor = '#ab6878';
  q5a3.style.color = 'white';
});
q5a4.addEventListener('click', function onClick() {
  q5a4.style.backgroundColor = '#ab6878';
  q5a4.style.color = 'white';
});


function updateResults() {
    confett.classList.add("active");
    popup.classList.add("active");
    
    if (fantasyScore >= 2) {
      console.log("Fantasy!")
      result.innerHTML = "You are Fantasy! Fantasy is a genre of speculative fiction involving magical elements, typically set in a fictional universe and sometimes inspired by mythology and folklore. My favorite Fantasy books that you should read are The Cruel Prince series by Holly Black, The Wrath and The Dawn by Renee Ahdieh, Heartless by Marissa Meyer, Six of Crows by Leigh Bardugo."
    } else if (romanceScore >= 2) {
      console.log("Romance!")
      result.innerHTML = "You are Romance! Romance is a type of genre fiction novel which places its primary focus on the relationship and romantic love between two people, and usually has an emotionally satisfying and optimistic ending. My favorite Romance books that you should read are Today, Tonight, Tomorrow by Rachel Solomon, Book Lovers by Emily Henry, and Heartstopper by Alice Oseman."
    } else if (realisticScore >= 2) {
      console.log("Realistic!")
      result.innerHTML = "You are Realistic Fiction! Trust me, that's one of the most underrated genres. Realistic Fiction is a literary genre, part of the broader realism in arts, that attempts to represent subject matter truthfully, avoiding speculative fiction and supernatural elements. My favorite Realistic Fiction Books that you should read are The Girl With the Louding Voice, Looking for Alaska, and Hold Still by Nina Lacour, and A Good Girl's Guide to Murder. "
    } else if (historicalScore >= 2) {
      console.log("Historical!")
      result.innerHTML = "You are Historical Fiction! This is one of my favorite genres. Historical Fiction is a literary genre in which the plot takes place in a setting related to past events, but is fictional. My favorite Historical Fiction books that you should read are Daisy Jones and the Six, The Seven Husbands of Evelyn Hugo, and The Song of Achilles. "
    }
}


function fantasy() {
  fantasyScore += 1;
  questionsAnswered += 1;
  disableButton();
  console.log("Questions Answered = " + questionsAnswered + " Fantasy Score = " + fantasyScore)
  if (questionsAnswered == 5) {
  console.log("Done!")
    updateResults();
}
}

function romance() {
  romanceScore += 1;
  questionsAnswered += 1;
  disableButton();
  console.log("Questions Answered = " + questionsAnswered + " Romance Score = " + romanceScore)
  if (questionsAnswered == 5) {
  console.log("Done!")
    updateResults();
}
}

function realistic() {
  realisticScore += 1;
  questionsAnswered += 1;
  disableButton();
  console.log("Questions Answered = " + questionsAnswered + " Realistic Score = " + realisticScore)
  if (questionsAnswered == 5) {
  console.log("Done!")
    updateResults();
}

}


function historical() {
  historicalScore += 1;
  questionsAnswered += 1;
  disableButton();
  console.log("Questions Answered = " + questionsAnswered + " Historical Score = " + historicalScore)
  if (questionsAnswered == 5) {
  console.log("Done!")
    updateResults();
}
}

console.log(questionsAnswered)

function disableButton (){
  if(questionsAnswered == 1){ // after question 1 diasable buttons 
    q1a1.disabled = true;
      q1a1.style.backgroundColor = "#88a2b3";
    q1a2.disabled = true;
      q1a2.style.backgroundColor = "#88a2b3";
    q1a3.disabled = true;
      q1a3.style.backgroundColor = "#88a2b3";
    q1a4.disabled = true;
      q1a4.style.backgroundColor = "#88a2b3";
}
  if(questionsAnswered == 2){ // after question 2 diasable buttons 
    q2a1.disabled = true;
      q2a1.style.backgroundColor = "#88a2b3";
    q2a2.disabled = true;
      q2a2.style.backgroundColor = "#88a2b3";
    q2a3.disabled = true;
      q2a3.style.backgroundColor = "#88a2b3";
    q2a4.disabled = true;
      q2a4.style.backgroundColor = "#88a2b3";
}
 if(questionsAnswered == 3){ // after question 3 diasable buttons 
    q3a1.disabled = true;
      q3a1.style.backgroundColor = "#88a2b3";
    q3a2.disabled = true;
      q3a2.style.backgroundColor = "#88a2b3";
    q3a3.disabled = true;
      q3a3.style.backgroundColor = "#88a2b3";
    q3a4.disabled = true;
      q3a4.style.backgroundColor = "#88a2b3";
} 
  if(questionsAnswered == 4){ // after question 4 diasable buttons 
    q4a1.disabled = true;
      q4a1.style.backgroundColor = "#88a2b3";
    q4a2.disabled = true;
      q4a2.style.backgroundColor = "#88a2b3";
    q4a3.disabled = true;
      q4a3.style.backgroundColor = "#88a2b3";
    q4a4.disabled = true;
      q4a4.style.backgroundColor = "#88a2b3";
} 
}